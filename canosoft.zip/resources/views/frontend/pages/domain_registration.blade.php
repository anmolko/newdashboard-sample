@extends('frontend.layouts.master')
@section('title') Domain Registration @endsection

@section('content')




@endsection