
			<!-- FOOTER-1
			============================================= -->
			<footer id="footer-1" class="bg-lightgrey footer division">
				<div class="container">


					<!-- FOOTER CONTENT -->
					<div class="row">	


						<!-- FOOTER INFO -->
						<div class="col-lg-4">
							<div class="footer-info mb-40">

								<!-- Footer Logo -->	
								<img class="footer-logo mb-25" src="<?php if(@$setting_data->logo){?><?php echo e(asset('/images/settings/'.@$setting_data->logo)); ?><?php } ?>" alt="footer-logo">

								<!-- Text -->	
								<p class="p-md"><?php if(!empty(@$setting_data->website_description)): ?> <?php echo ucfirst(@$setting_data->website_description); ?> <?php else: ?> Canosoft - Let's make IT happen <?php endif; ?> 
								</p>

							</div>	
						</div>	


						<!-- FOOTER LINKS -->
						<div class="col-sm-6 col-md-3 col-lg-2">
							<div class="footer-links mb-40">
							
								<!-- Title -->
								<h6 class="h6-xl">Company</h6>

								<!-- Footer Links -->
								<ul class="foo-links text-secondary clearfix">
									<li><p class="p-md"><a href="<?php echo e(route('service.frontend')); ?>">Services</a></p></li>
									<li><p class="p-md"><a href="<?php echo e(route('career.frontend')); ?>">Careers</a></p></li>
									<li><p class="p-md"><a href="<?php echo e(route('blog.frontend')); ?>">Press & Media</a></p></li>
									<li><p class="p-md"><a href="<?php echo e(route('contact')); ?>">Contact Us</a></p></li>		
									<li><p class="p-md"><a href="<?php echo e(route('get-quote')); ?>">Get Quote</a></p></li>		
								</ul>

							</div>
						</div>


						<!-- FOOTER LINKS -->
						<div class="col-sm-6 col-md-3 col-lg-2">
							<div class="footer-links mb-40">
												
								<!-- Title -->
								<h6 class="h6-xl"><?php if(@$footer_nav_title1 !== null): ?> <?php echo e(@$footer_nav_title1); ?> <?php else: ?> Quick Links <?php endif; ?></h6>

								<!-- Footer List -->
								<ul class="foo-links text-secondary clearfix">
									<?php if(!empty($footer_nav_data1)): ?>
										<?php $__currentLoopData = $footer_nav_data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(!empty($nav->children[0])): ?>
											<?php else: ?>
												<?php if($nav->type == 'custom'): ?>
													<li><p class="p-md">
														<?php if(str_contains(@$nav->slug,'http')): ?>
														<a href="<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
														<?php else: ?>
														<a href="/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
														<?php endif; ?>
													</p>
													</li>
											
												<?php elseif($nav->type == 'post'): ?>
													<li><p class="p-md">
														<a href="<?php echo e(url('blog')); ?>/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
													</p>
													</li>
												<?php elseif($nav->type == 'service'): ?>
													<li><p class="p-md">
														<a href="<?php echo e(url('service')); ?>/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
													</p>
													</li>
												<?php else: ?>
													<li><p class="p-md">
														<a href="<?php echo e(url('/')); ?>/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
													</p>
													</li>
												<?php endif; ?>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
						
								</ul>
							
							</div>	
						</div>


						<!-- FOOTER LINKS -->
						<div class="col-sm-6 col-md-3 col-lg-2">
							<div class="footer-links mb-40">
							
								<!-- Title -->
								<h6 class="h6-xl"><?php if(@$footer_nav_title2 !== null): ?> <?php echo e(@$footer_nav_title2); ?> <?php else: ?> Legal <?php endif; ?></h6>

								<!-- Footer List -->
								<ul class="foo-links text-secondary clearfix">							
									<?php if(!empty($footer_nav_data2)): ?>
										<?php $__currentLoopData = $footer_nav_data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(!empty($nav->children[0])): ?>
											<?php else: ?>
												<?php if($nav->type == 'custom'): ?>
													<li><p class="p-md">
														<?php if(str_contains(@$nav->slug,'http')): ?>
														<a href="<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
														<?php else: ?>
														<a href="/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
														<?php endif; ?>
													</p>
													</li>
											
												<?php elseif($nav->type == 'post'): ?>
													<li><p class="p-md">
														<a href="<?php echo e(url('blog')); ?>/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
													</p>
													</li>
												<?php elseif($nav->type == 'service'): ?>
													<li><p class="p-md">
														<a href="<?php echo e(url('service')); ?>/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
													</p>
													</li>
												<?php else: ?>
													<li><p class="p-md">
														<a href="<?php echo e(url('/')); ?>/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
													</p>
													</li>
												<?php endif; ?>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>				
								</ul>

							</div>
						</div>


						<!-- FOOTER LINKS -->
						<div class="col-sm-6 col-md-3 col-lg-2">
							<div class="footer-links mb-40">
							
								<!-- Title -->
								<h6 class="h6-xl"><?php if(@$footer_nav_title3 !== null): ?> <?php echo e(@$footer_nav_title3); ?> <?php else: ?> Support <?php endif; ?></h6>

								<!-- Footer Links -->
								<ul class="foo-links text-secondary clearfix">
									<?php if(!empty($footer_nav_data3)): ?>
										<?php $__currentLoopData = $footer_nav_data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(!empty($nav->children[0])): ?>
											<?php else: ?>
												<?php if($nav->type == 'custom'): ?>
													<li><p class="p-md">
														<?php if(str_contains(@$nav->slug,'http')): ?>
														<a href="<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
														<?php else: ?>
														<a href="/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
														<?php endif; ?>
													</p>
													</li>
											
												<?php elseif($nav->type == 'post'): ?>
													<li><p class="p-md">
														<a href="<?php echo e(url('blog')); ?>/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
													</p>
													</li>
												<?php elseif($nav->type == 'service'): ?>
													<li><p class="p-md">
														<a href="<?php echo e(url('service')); ?>/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
													</p>
													</li>
												<?php else: ?>
													<li><p class="p-md">
														<a href="<?php echo e(url('/')); ?>/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>>  <?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
													</p>
													</li>
												<?php endif; ?>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>									
								</ul>

							</div>
						</div>


					</div>	<!-- END FOOTER CONTENT -->


					<hr>


					<!-- BOTTOM FOOTER -->
					<div class="bottom-footer">
						<div class="row row-cols-1 row-cols-md-2 d-flex align-items-center">


							<!-- FOOTER COPYRIGHT -->
							<div class="col">
								<div class="footer-copyright">
									<p>&copy; <?php echo e(date("Y")); ?> Canosoft Technology. All Rights Reserved</p>
								</div>
							</div>


							<!-- BOTTOM FOOTER LINKS -->
							<div class="col">
								<ul class="bottom-footer-list text-secondary text-end">
									<?php if(!empty(@$setting_data->facebook)): ?>
										<li class="first-li"><p><a href="<?php if(!empty(@$setting_data->facebook)): ?> <?php echo e(@$setting_data->facebook); ?> <?php endif; ?>" target="_blank">Facebook</a></p></li>
									<?php endif; ?>
									<?php if(!empty(@$setting_data->youtube)): ?>
										<li><p><a href="<?php if(!empty(@$setting_data->youtube)): ?> <?php echo e(@$setting_data->youtube); ?> <?php endif; ?>" target="_blank">Youtube</a></p></li>
									<?php endif; ?>
									<?php if(!empty(@$setting_data->instagram)): ?>
										<li><p><a href="<?php if(!empty(@$setting_data->instagram)): ?> <?php echo e(@$setting_data->instagram); ?> <?php endif; ?>" target="_blank">Instagram</a></p></li>
									<?php endif; ?>
									<?php if(!empty(@$setting_data->linkedin)): ?>
										<li class="last-li"><p><a href="<?php if(!empty(@$setting_data->linkedin)): ?> <?php echo e(@$setting_data->linkedin); ?> <?php endif; ?>" target="_blank">LinkedIn</a></p></li>
									<?php endif; ?>
								</ul>
							</div>


						</div>  <!-- End row -->
					</div>	<!-- BOTTOM FOOTER -->


				</div>
			</footer>	<!-- END FOOTER-1 -->


		</div>	<!-- END PAGE CONTENT -->	
			

		<!-- EXTERNAL SCRIPTS
		============================================= -->	

		<script src="<?php echo e(asset('assets/frontend/js/jquery-3.6.0.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>	
		<script src="<?php echo e(asset('assets/frontend/js/modernizr.custom.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/jquery.easing.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/jquery.appear.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/jquery.scrollto.js')); ?>"></script>	
		<script src="<?php echo e(asset('assets/frontend/js/menu.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/imagesloaded.pkgd.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/isotope.pkgd.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/owl.carousel.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/jquery.magnific-popup.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/jquery.validate.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/frontend/js/jquery.ajaxchimp.min.js')); ?>"></script>	
		<script src="<?php echo e(asset('assets/frontend/js/wow.js')); ?>"></script>
				
		<script src="<?php echo e(asset('assets/frontend/js/custom.js')); ?>"></script>
		<script type="text/javascript">
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
		</script>
        <?php echo $__env->yieldContent('js'); ?>




	</body>


</html><?php /**PATH D:\newdashboard-sample\resources\views/frontend/partials/footer.blade.php ENDPATH**/ ?>