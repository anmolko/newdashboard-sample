<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="author" content="Canosoft Technology"/>	
		<meta name="description" content="<?php if(!empty(@$setting_data->website_description)): ?> <?php echo e(ucwords(@$setting_data->website_description)); ?> <?php else: ?> Canosoft - Let's make IT happen <?php endif; ?> "/>
		<meta name="keywords" content="<?php if(!empty(@$setting_data->website_keyword)): ?> <?php echo e(@$setting_data->website_keyword); ?> <?php else: ?> Canosoft - Let's make IT happen <?php endif; ?> ">	
		<link rel="canonical" href="" />
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

			<!-- SITE TITLE -->
		<?php if(\Request::is('/')): ?>
		    <title><?php if(!empty(@$setting_data->website_name)): ?> <?php echo e(ucwords(@$setting_data->website_name)); ?> <?php else: ?> Canosoft - Let's make IT happen <?php endif; ?> </title>
		<?php else: ?>
            <title><?php echo $__env->yieldContent('title'); ?> | <?php if(!empty(@$setting_data->website_name)): ?> <?php echo e(ucwords(@$setting_data->website_name)); ?> <?php else: ?> Canosoft - Let's make IT happen <?php endif; ?> </title>
		<?php endif; ?>			
		<meta property="og:title" content="Home" />
		<meta property="og:type" content="article" />
		<meta property="og:url" content="" />
		<meta property="og:site_name" content="Canosoft - Let's make IT happen" />
		<meta property="og:description" content="<?php if(!empty(@$setting_data->website_description)): ?> <?php echo e(ucwords(@$setting_data->website_description)); ?> <?php else: ?> Canosoft - Let's make IT happen <?php endif; ?> " />


  	
		<!-- FAVICON AND TOUCH ICONS -->


		<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/frontend/images/apple-touch-icon.png')); ?>">
		<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/frontend/images/favicon-32x32.png')); ?>">
		<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/frontend/images/favicon-16x16.png')); ?>">
		<link rel="manifest" href="<?php echo e(asset('assets/frontend/images/site.webmanifest')); ?>">


		<!-- GOOGLE FONTS -->
		<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;700&amp;display=swap" rel="stylesheet">

		<!-- BOOTSTRAP CSS -->
		<link href="<?php echo e(asset('assets/frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
		<!-- FONT ICONS -->
		<link href="<?php echo e(asset('assets/frontend/css/flaticon.css')); ?>" rel="stylesheet">

		<!-- PLUGINS STYLESHEET -->
		<link href="<?php echo e(asset('assets/frontend/css/menu.css')); ?>" rel="stylesheet">	
		<link id="effect" href="<?php echo e(asset('assets/frontend/css/dropdown-effects/fade-down.css')); ?>" media="all" rel="stylesheet">
		<link href="<?php echo e(asset('assets/frontend/css/magnific-popup.css')); ?>" rel="stylesheet">	
		<link href="<?php echo e(asset('assets/frontend/css/owl.carousel.min.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('assets/frontend/css/owl.theme.default.min.css')); ?>" rel="stylesheet">

		<!-- ON SCROLL ANIMATION -->
		<link href="<?php echo e(asset('assets/frontend/css/animate.css')); ?>" rel="stylesheet">

		<!-- TEMPLATE CSS -->
		<link href="<?php echo e(asset('assets/frontend/css/style.css')); ?>" rel="stylesheet"> 
		
		<!-- RESPONSIVE CSS -->
		<link href="<?php echo e(asset('assets/frontend/css/responsive.css')); ?>" rel="stylesheet">
		<style>
			.tra-menu.navbar-light .scroll .wsmenu>.wsmenu-list>li.active a,.tra-menu.navbar-dark .wsmenu>.wsmenu-list>li.active>a
			{
				color:#2F72A3;
			}
		</style>
        <?php echo $__env->yieldContent('css'); ?>

	</head>



	<body>


		<!-- PRELOADER SPINNER
		============================================= -->	
		<?php if(\Request::is('/')): ?>
		<div id="loading" class="skyblue-loading">
			<div id="loading-center">
				<div id="loading-center-absolute">
					<div class="object" id="object_one"></div>
					<div class="object" id="object_two"></div>
					<div class="object" id="object_three"></div>
					<div class="object" id="object_four"></div>
				</div>
			</div>
		</div>
		<?php endif; ?>




		<!-- PAGE CONTENT
		============================================= -->	
		<div id="page" class="page">


			<!-- HEADER
			============================================= -->
			<header id="header" class="header tra-menu <?php if(\Request::is('/') || \Request::route()->getName()=='faq.frontend' || \Request::route()->getName()=='career.frontend' || \Request::route()->getName()=='work.frontend'): ?> navbar-light <?php else: ?> navbar-dark <?php endif; ?>">
				<div class="header-wrapper">

					<!-- MOBILE HEADER -->
				    <div class="wsmobileheader clearfix">	  	
				    	<span class="smllogo"><img src="<?php if(@$setting_data->logo){?><?php echo e(asset('/images/settings/'.@$setting_data->logo)); ?><?php }?>" alt="mobile-logo"/></span>
				    	<a id="wsnavtoggle" class="wsanimated-arrow"><span></span></a>	
				 	</div>


				 	<!-- NAVIGATION MENU -->
				  	<div class="wsmainfull menu clearfix">
	    				<div class="wsmainwp clearfix">


	    					<!-- HEADER LOGO -->
	    					<div class="desktoplogo"><a href="/" class="logo-black"><img src="<?php if(@$setting_data->logo){?><?php echo e(asset('/images/settings/'.@$setting_data->logo)); ?><?php }?>" alt="header-logo"></a></div>
	    					<div class="desktoplogo"><a href="/" class="logo-white"><img src="<?php if(@$setting_data->logo_white){?><?php echo e(asset('/images/settings/'.@$setting_data->logo_white)); ?><?php }?>" alt="header-logo"></a></div>


	    					<!-- MAIN MENU -->
	      					<nav class="wsmenu clearfix">
	        					<ul class="wsmenu-list nav-skyblue-hover">

	        					
									<li class="nl-simple <?php echo e(request()->is('/') ? 'active' : ''); ?>" aria-haspopup="true" >
										<a href="/" class="">Home</a>
									</li>

									<?php if(!empty($top_nav_data)): ?>
										<?php $__currentLoopData = $top_nav_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(!empty($nav->children[0])): ?>

										<li aria-haspopup="true" class="<?php echo e(request()->is(@$nav->slug)  ? 'active' : ''); ?>"><a href="#"><?php if(@$nav->name == NULL): ?> <?php echo e(ucwords(@$nav->title)); ?> <?php else: ?> <?php echo e(ucwords(@$nav->name)); ?> <?php endif; ?>  <span class="wsarrow"></span></a>

											<ul class="sub-menu">
												<?php $__currentLoopData = $nav->children[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childNav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($childNav->type == 'custom'): ?>
													<li aria-haspopup="true" class="<?php echo e(request()->is(@$childNav->slug) ? 'active' : ''); ?>">
														<a href="/<?php echo e(@$childNav->slug); ?>"  <?php if(@$childNav->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if($childNav->name == NULL): ?> <?php echo e(@$childNav->title); ?> <?php else: ?> <?php echo e(@$childNav->name); ?> <?php endif; ?></a>
													</li>
												
												<?php elseif($childNav->type == 'post'): ?>
													<li aria-haspopup="true" class="<?php echo e(request()->is('blog/'.@$childNav->slug) ? 'active' : ''); ?>">
														<a href="<?php echo e(url('blog')); ?>/<?php echo e(@$childNav->slug); ?>"  <?php if(@$childNav->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if($childNav->name == NULL): ?> <?php echo e(@$childNav->title); ?> <?php else: ?> <?php echo e(@$childNav->name); ?> <?php endif; ?></a>
													</li>
												<?php elseif($childNav->type == 'service'): ?>
													<li aria-haspopup="true" class="<?php echo e(request()->is('service/'.@$childNav->slug) ? 'active' : ''); ?>">
														<a href="<?php echo e(url('service')); ?>/<?php echo e(@$childNav->slug); ?>"  <?php if(@$childNav->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if($childNav->name == NULL): ?> <?php echo e(@$childNav->title); ?> <?php else: ?> <?php echo e(@$childNav->name); ?> <?php endif; ?></a>
													</li>
													
												<?php else: ?>
													<li aria-haspopup="true" class="<?php echo e(request()->is(@$childNav->slug) ? 'active' : ''); ?>">
														<a href="<?php echo e(url('/')); ?>/<?php echo e(@$childNav->slug); ?>"  <?php if(@$childNav->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if($childNav->name == NULL): ?> <?php echo e(@$childNav->title); ?> <?php else: ?> <?php echo e(@$childNav->name); ?> <?php endif; ?></a>
													</li>
												<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

											</ul>
										</li>

										<?php else: ?>
											<?php if($nav->type == 'custom'): ?>
												<li class="nl-simple <?php echo e(request()->is(@$nav->slug.'*') ? 'active' : ''); ?>" aria-haspopup="true" >
													<a href="/<?php echo e($nav->slug); ?>" class=""<?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>><?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
												</li>
											<?php elseif($nav->type == 'post'): ?>
												<li class="nl-simple <?php echo e(request()->is('blog/'.@$nav->slug.'*') ? 'active' : ''); ?>" aria-haspopup="true" >
													<a href="<?php echo e(url('blog')); ?>/<?php echo e($nav->slug); ?>" class="" <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>><?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
												</li>
											<?php elseif($nav->type == 'service'): ?>
												<li class="nl-simple <?php echo e(request()->is('service/'.@$nav->slug.'*') ? 'active' : ''); ?>" aria-haspopup="true" >
													<a href="<?php echo e(url('service')); ?>/<?php echo e($nav->slug); ?>" class="" <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>><?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
												</li>
												
											<?php else: ?>
												<li class="nl-simple <?php echo e(request()->is(@$nav->slug.'*') ? 'active' : ''); ?>" aria-haspopup="true" >
													<a href="<?php echo e(url('/')); ?>/<?php echo e($nav->slug); ?>" class="" <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>><?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a>
												</li>
											<?php endif; ?>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>


	        					</ul>
	        				</nav>	<!-- END MAIN MENU -->


	    				</div>
	    			</div>	<!-- END NAVIGATION MENU -->


				</div>     <!-- End header-wrapper -->
			</header>	<!-- END HEADER --><?php /**PATH D:\newdashboard-sample\resources\views/frontend/partials/header.blade.php ENDPATH**/ ?>